package com.mycompany.parqueadero;

import java.time.LocalTime;

public class Vehiculo {
    private String placa;
    private String marca;
    private String modelo;
    private LocalTime hora_entrada, hora_salida;
    private Automovil automovil;
    private Motocicleta motocicleta;
    private Camion camion;
    private static int contador = 0;
    private int numVehiculo;
    private String tipoVehiculo;

    public Vehiculo(String placa, String marca, String modelo, Automovil automovil){
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.hora_entrada = null; // Inicialmente no hay hora de entrada
        this.hora_salida = null; // Inicialmente no hay hora de salida
        this.automovil = automovil;
        this.contador++;
        this.numVehiculo = contador;
        this.tipoVehiculo = "Automovil";
    }

    public Vehiculo(String placa, String marca, String modelo, Motocicleta motocicleta){
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.hora_entrada = null; // Inicialmente no hay hora de entrada
        this.hora_salida = null; // Inicialmente no hay hora de salida
        this.motocicleta = motocicleta;
        this.contador++;
        this.numVehiculo = contador;
        this.tipoVehiculo = "Motocicleta";
    }

    public Vehiculo(String placa, String marca, String modelo, Camion camion){
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.hora_entrada = null; // Inicialmente no hay hora de entrada
        this.hora_salida = null; // Inicialmente no hay hora de salida
        this.camion = camion;
        this.contador++;
        this.numVehiculo = contador;
        this.tipoVehiculo = "Camion";
    }

    public void setPlaca(String placa){
        this.placa = placa;
    }

    public void setMarca(String marca){
        this.marca = marca;
    }

    public void setModelo(String modelo){
        this.modelo = modelo;
    }

    public void setHoraEntrada(int hora, int minuto){
        this.hora_entrada = LocalTime.of(hora, minuto);
    }

    public void setHoraSalida(int hora, int minuto){
        this.hora_salida = LocalTime.of(hora, minuto);
    }

    public String getPlaca(){
        return placa;
    }

    public String getMarca(){
        return marca;
    }

    public String getModelo(){
        return modelo;
    }

    public LocalTime getHoraEntrada(){
        return hora_entrada;
    }

    public LocalTime getHoraSalida(){
        return hora_salida;
    }

    public String getTipoVehiculo(){
        return tipoVehiculo;
    }

    @Override
    public String toString() {
        if(tipoVehiculo == "Automovil") {
            return "Vehiculo{" +
                    "placa='" + placa + '\'' +
                    ", marca='" + marca + '\'' +
                    ", modelo='" + modelo + '\'' +
                    ", hora_entrada=" + hora_entrada + '\'' +
                    ", hora_salida=" + hora_salida + '\'' +
                    ", numVehiculo=" + numVehiculo + '\'' +
                    ", tipoVehiculo='" + tipoVehiculo + '\'' +
                    automovil + '\'' +
                    '}';
        } 
        else if(tipoVehiculo == "Motocicleta") {
            return "Vehiculo{" +
                    "placa='" + placa + '\'' +
                    ", marca='" + marca + '\'' +
                    ", modelo='" + modelo + '\'' +
                    ", hora_entrada=" + hora_entrada + '\'' +
                    ", hora_salida=" + hora_salida + '\'' +
                    ", numVehiculo=" + numVehiculo + '\'' +
                    ", tipoVehiculo='" + tipoVehiculo + '\'' +
                    motocicleta + '\'' +
                    '}';
        } 
        else if(tipoVehiculo == "Camion") {
            return "Vehiculo{" +
                    "placa='" + placa + '\'' +
                    ", marca='" + marca + '\'' +
                    ", modelo='" + modelo + '\'' +
                    ", hora_entrada=" + hora_entrada + '\'' +
                    ", hora_salida=" + hora_salida + '\'' +
                    ", numVehiculo=" + numVehiculo + '\'' +
                    ", tipoVehiculo='" + tipoVehiculo + '\'' +
                    camion + '\'' +
                    '}';
        }
        return "Vehiculo{" +
                "placa='" + placa + '\'' +
                ", marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", hora_entrada=" + hora_entrada + '\'' +
                ", hora_salida=" + hora_salida + '\'' +
                ", numVehiculo=" + numVehiculo +
                '}';
    }
}
