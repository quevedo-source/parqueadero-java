package com.mycompany.parqueadero;

public class Camion {
    private int capacidad_carga;
    private int numCamion;
    private static int contador = 0;

    public Camion(int capacidad_carga) {
        this.capacidad_carga = capacidad_carga;
        Camion.contador++;
        this.numCamion = contador;
    }

    public void setCapacidadCarga(int capacidad_carga) {
        this.capacidad_carga = capacidad_carga;
    }

    public int getCapacidadCarga() {
        return capacidad_carga;
    }

    @Override
    public String toString() {
        return  ", Numero de Camion=" + numCamion + '\'' +
                ", capacidad_carga=" + capacidad_carga + "Kg" +
                '}';
    }
}
