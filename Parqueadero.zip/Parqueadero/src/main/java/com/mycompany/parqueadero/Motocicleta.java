package com.mycompany.parqueadero;

public class Motocicleta {
    private String cilindraje;
    private int numMoto;
    private static int contador = 0;

    public Motocicleta(String cilindraje){
        this.cilindraje = cilindraje;
        Motocicleta.contador++;
        this.numMoto = contador;
    }

    public void setCilindraje(String cilindraje){
        this.cilindraje = cilindraje;
    }

    public String getCilindraje(){
        return cilindraje;
    }

    @Override
    public String toString() {
        return  ", Numero de Moto=" + numMoto + '\'' +
                ", cilindraje=" + cilindraje +
                '}';
    }
}
