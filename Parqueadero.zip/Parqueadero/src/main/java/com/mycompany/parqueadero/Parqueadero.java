/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.parqueadero;

import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author Juan Diego Quevedo
 */
public class Parqueadero {

    public Parqueadero() {
    }

    public void addAutomovil(String placa, String marca, String modelo, int hora, int minuto, List<Vehiculo> vehiculos, String tipo_combustible) {
        Automovil automovil = new Automovil(tipo_combustible);
        Vehiculo vehiculo = new Vehiculo(placa, marca, modelo, automovil);
        vehiculos.add(vehiculo);
        registrarEntrada(placa, hora, minuto, vehiculos);
        System.out.println("Automóvil registrado");
    }

    public void addMotocicleta(String placa, String marca, String modelo, int hora, int minuto, List<Vehiculo> vehiculos, String cilindraje) {
        Motocicleta motocicleta = new Motocicleta(cilindraje);
        Vehiculo vehiculo = new Vehiculo(placa, marca, modelo, motocicleta);
        vehiculos.add(vehiculo);
        registrarEntrada(placa, hora, minuto, vehiculos);
        System.out.println("Motocicleta registrada");
    }

    public void addCamion(String placa, String marca, String modelo, int hora, int minuto, List<Vehiculo> vehiculos, int capacidad_carga) {
        Camion camion = new Camion(capacidad_carga);
        Vehiculo vehiculo = new Vehiculo(placa, marca, modelo, camion);
        vehiculos.add(vehiculo);
        registrarEntrada(placa, hora, minuto, vehiculos);
        System.out.println("Camión registrado");
    }

    public void getVehiculos(List<Vehiculo> vehiculos){
        for(Vehiculo vehiculo : vehiculos){
            System.out.println(vehiculo);
        }
    }

    public void registrarEntrada(String placa, int hora, int minuto, List<Vehiculo> vehiculos){
        for(Vehiculo vehiculo : vehiculos){
            if(vehiculo.getPlaca().equals(placa)){
                if(vehiculo.getHoraEntrada() == null){ 
                    vehiculo.setHoraEntrada(hora, minuto);
                    System.out.println("Entrada registrada para el vehículo con placa: " + placa);
                    return; // Salir después de registrar la entrada
                }
                else{
                    System.out.println("El vehículo ya tiene una hora de entrada registrada.");
                    return; // Salir si ya hay una hora de entrada
                }
            }
        }
        System.out.println("Vehículo no encontrado.");
    }

    public void registrarSalida(String placa, int hora, int minuto, List<Vehiculo> vehiculos) {
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getPlaca().equals(placa)) {
                if(vehiculo.getHoraEntrada() != null){
                    vehiculo.setHoraSalida(hora, minuto);
                    System.out.println("Salida registrada para el vehículo con placa: " + placa);
                    System.out.println(calcularCosto(placa, vehiculos) + " pesos");
                    return; // Salir después de registrar la salida
                }
                else{
                    System.out.println("El vehículo no tiene una hora de entrada registrada.");
                    return;
                }
            }
        }
        System.out.println("Vehículo no encontrado.");
    }

    public String consultarEstado(String placa, List<Vehiculo> vehiculos){
        for(Vehiculo vehiculo : vehiculos){
            if(vehiculo.getPlaca().equals(placa)){
                if(vehiculo.getHoraEntrada() != null && vehiculo.getHoraSalida() == null){
                    return "El vehiculo con placa " + placa + " esta actalmente en el parqueadero";
                }
                else if(vehiculo.getHoraEntrada() != null && vehiculo.getHoraSalida() != null){
                    return "El vehiculo con placa " + placa + " ya salio del parqueadero";
                }
                else{
                    return "El vehiculo con placa " + placa + " no ha ingresado al parqueadero";
                }
            }
        }
        return "Vehículo no encontrado.";
    }

    public double calcularCosto(String placa, List<Vehiculo> vehiculos){
        for(Vehiculo vehiculo : vehiculos){
            if(vehiculo.getPlaca().equals(placa)){
                if(vehiculo.getHoraEntrada() != null && vehiculo.getHoraSalida() != null){
                    long minutosEstacionado = java.time.Duration.between(vehiculo.getHoraEntrada(), vehiculo.getHoraSalida()).toMinutes();
                    if(vehiculo.getTipoVehiculo().equals("Automovil")){
                        return (minutosEstacionado / 60.0) * 3000; // Tarifa por hora
                    }
                    else if(vehiculo.getTipoVehiculo().equals("Motocicleta")){
                        return (minutosEstacionado / 60.0) * 30000; // Tarifa por hora
                    }
                    else if(vehiculo.getTipoVehiculo().equals("Camion")){
                        return (minutosEstacionado / 60.0) * 300000; // Tarifa por hora
                    }
                }
                else{
                    System.out.println("El vehículo no tiene horas de entrada y salida registradas.");
                    return 0.0; // Indicar que no se puede calcular el costo
                }
            }
        }
        System.out.println("Vehículo no encontrado.");
        return 0.0;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Parqueadero parqueadero = new Parqueadero();
        List<Vehiculo> vehiculos = new ArrayList<>();

        String tipo, placa, marca, modelo, tipo_combustible, cilindraje;
        int capacidadCarga, hora, minuto;

        int simulacion = 1;
        int opcion;

        System.out.println("Bienvenido al sistema de parqueadero");
        while (simulacion == 1) {
            System.out.println("Seleccione una opcion:");
            System.out.println("1. Registrar entrada de vehículo");
            System.out.println("2. Registrar salida de vehículo");
            System.out.println("3. Consultar estado de vehículo");
            System.out.println("4. Registro de vehículos");
            opcion = sc.nextInt();
            sc.nextLine(); // Consumir el salto de línea pendiente
            switch (opcion) {
                case 1:
                    System.out.println("Ingrese la cantidad de vehiculos a registrar:");
                    int cantidadVehiculos = sc.nextInt();
                    sc.nextLine(); // Consumir el salto de línea pendiente
                    for(int i = 0; i < cantidadVehiculos; i++){
                        System.out.println("Ingrese el tipo de vehiculo (A: Automovil, M: Motocicleta, C: Camion):");
                        tipo = sc.nextLine();
                        System.out.println("Ingrese la placa del vehiculo:");
                        placa = sc.nextLine();
                        System.out.println("Ingrese la marca del vehiculo:");
                        marca = sc.nextLine();
                        System.out.println("Ingrese el modelo del vehiculo:");
                        modelo = sc.nextLine();
                        System.out.println("Ingrese la hora de entrada (0-23):");
                        hora = sc.nextInt();
                        System.out.println("Ingrese los minutos de entrada (0-59):");
                        minuto = sc.nextInt();
                        sc.nextLine(); // Consumir el salto de línea pendiente
                        if(tipo.equals("A")){
                            System.out.println("Ingrese el tipo de combustible del automovil:");
                            tipo_combustible = sc.nextLine();
                            parqueadero.addAutomovil(placa, marca, modelo, hora, minuto, vehiculos, tipo_combustible);
                        }
                        else if(tipo.equals("M")){
                            System.out.println("Ingrese el cilindraje de la motocicleta:");
                            cilindraje = sc.nextLine();
                            parqueadero.addMotocicleta(placa, marca, modelo, hora, minuto, vehiculos, cilindraje);
                        }
                        else if(tipo.equals("C")){
                            System.out.println("Ingrese la capacidad de carga del camión (Kg):");
                            capacidadCarga = sc.nextInt();
                            sc.nextLine(); // Consumir el salto de línea pendiente
                            parqueadero.addCamion(placa, marca, modelo, hora, minuto, vehiculos, capacidadCarga);
                        }
                        else{
                            System.out.println("Tipo de vehículo no reconocido.");
                        }
                    }
                    break;
                case 2:
                    System.out.println("Ingrese la placa del vehiculo para registrar la salida:");
                    placa = sc.nextLine();
                    System.out.println("Ingrese la hora de salida (0-23):");
                    hora = sc.nextInt();
                    sc.nextLine(); // Consumir el salto de línea pendiente
                    System.out.println("Ingrese los minutos de salida (0-59):");
                    minuto = sc.nextInt();
                    sc.nextLine(); // Consumir el salto de línea pendiente
                    parqueadero.registrarSalida(placa, hora, minuto, vehiculos);
                    break;
                case 3:
                    System.out.println("Ingrese la placa del vehiculo para consultar su estado:");
                    placa = sc.nextLine();
                    System.out.println(parqueadero.consultarEstado(placa, vehiculos));
                    break;
                case 4:
                    System.out.println("Vehículos registrados:");
                    if(vehiculos.isEmpty()){
                        System.out.println("No hay vehículos registrados.");
                    } 
                    else {
                        parqueadero.getVehiculos(vehiculos);
                    }
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, intente de nuevo.");
            }
            System.out.println("¿Desea realizar otra operación? (1: Sí, 0: No)");
            simulacion = sc.nextInt();
            sc.nextLine(); // Consumir el salto de línea pendiente
        }
        sc.close();
    }
}
