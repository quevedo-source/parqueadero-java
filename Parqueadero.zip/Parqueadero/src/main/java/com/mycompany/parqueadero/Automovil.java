package com.mycompany.parqueadero;

public class Automovil {
    private String tipo_combustible;
    private int numAuto;
    private static int contador = 0;

    public Automovil(String tipo_combustible){
        this.tipo_combustible = tipo_combustible;
        Automovil.contador++;
        this.numAuto = contador;
    }

    public void setTipoCombustible(String tipo_combustible){
        this.tipo_combustible = tipo_combustible;
    }

    public String getTipoCombustible(){
        return tipo_combustible;
    }

    @Override
    public String toString() {
        return  ", Numero de Auto=" + numAuto + '\'' +
                ", tipo_combustible='" + tipo_combustible + '\'' +
                '}';
    }
}
