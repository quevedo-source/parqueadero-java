package com.mycompany.parqueadero;

public class Automovil {
    private String tipocombustible;
    private int numAuto;
    private static int contador = 0;

    public Automovil(String tipocombustible){
        this.tipocombustible = tipocombustible;
        Automovil.contador++;
        this.numAuto = contador;
    }

    public void setTipoCombustible(String tipocombustible){
        this.tipocombustible = tipocombustible;
    }

    public String getTipoCombustible(){
        return tipocombustible;
    }

    @Override
    public String toString() {
        return  ", Numero de Auto=" + numAuto + '\'' +
                ", tipo_combustible='" + tipocombustible + '\'' +
                '}';
    }
}
